enchant();

window.onload = function(){
    game = new Game(320, 320);
    game.rootScene.backgroundColor = "rgb(175, 225, 130)";
    game.preload(['card.png','kigou.png','sora.png','quiz.png']);
    game.fps = 30;
    game.onload = function(){

        game.keybind(90, 'a');  //90はZキー
        game.keybind(88, 'b');  //88はXキー

        tpha = 0;
        maisu = 0;
        phase = 0;
        select = 0; //0=Big, 1=Small
        hantei = 0; //0=OK, 1=NG
        wait = 0;

        Cdraw = 0;
        Cdname = "";
        Cdarea = 0;
        Cdframe = 0;
        Cname1 = "";
        Carea1 = 0;
        Cframe1 = 0;
        Cname2 = "";
        Carea2 = 0;
        Cframe2 = 0;

        game.addEventListener('enterframe', function(){

    		var keys = xhrPad.read();         // コントローラ・キーの読み出し

		    if( keys.up == true ) {              // 上ボタン
		        game.input.up = true;
				game.input.down = false;
				game.input.left = false;
				game.input.right = false;
		    } else if( keys.down == true ) {     // 下ボタン
				game.input.up = false;
				game.input.down = true;
				game.input.left = false;
				game.input.right = false;
		    } else if( keys.left == true ) {     // 左ボタン
				game.input.up = false;
				game.input.down = false;
				game.input.left = true;
				game.input.right = false;
		    } else if( keys.right == true ) {    // 右ボタン
				game.input.up = false;
				game.input.down = false;
				game.input.left = false;
				game.input.right = true;
		    }
		    if( keys.a == true ) {            // Aボタン
		        game.input.a = true;
		    } else {
				game.input.a = false;
			}
		    if( keys.b == true ) {            // Bボタン
		        game.input.b = true;
		    } else {
				game.input.b = false;
			}

            Cdraw = rand(50);
            if (Cdraw == 1)      {Cdname = "     Japan     ", Cdarea = 377972, Cdframe = 1;}
            else if (Cdraw ==  2){Cdname = "    Finland    ", Cdarea = 338431, Cdframe = 2;}
            else if (Cdraw ==  3){Cdname = "    Russia     ", Cdarea = 17098242, Cdframe = 3;}
            else if (Cdraw ==  4){Cdname = "   Australia   ", Cdarea = 7692024, Cdframe = 4;}
            else if (Cdraw ==  5){Cdname = "  New Zealand  ", Cdarea = 270467, Cdframe = 5;}
            else if (Cdraw ==  6){Cdname = "     Spain     ", Cdarea = 505992, Cdframe = 6;}
            else if (Cdraw ==  7){Cdname = "     India     ", Cdarea = 3287263, Cdframe = 7;}
            else if (Cdraw ==  8){Cdname = "     Egypt     ", Cdarea = 1001450, Cdframe = 8;}
            else if (Cdraw ==  9){Cdname = "  Switzerland  ", Cdarea = 41285, Cdframe = 9;}
            else if (Cdraw == 10){Cdname = "    America    ", Cdarea = 9629091, Cdframe = 10;}
            else if (Cdraw == 11){Cdname = "    Morroco    ", Cdarea = 446550, Cdframe = 11;}
            else if (Cdraw == 12){Cdname = "   Singapore   ", Cdarea = 714, Cdframe = 12;}
            else if (Cdraw == 13){Cdname = "     Italy     ", Cdarea = 301336, Cdframe = 13;}
            else if (Cdraw == 14){Cdname = "the Netherlands", Cdarea = 37354, Cdframe = 14;}
            else if (Cdraw == 15){Cdname = "    Israel     ", Cdarea = 22072, Cdframe = 15;}
            else if (Cdraw == 16){Cdname = "   Argentina   ", Cdarea = 2780400, Cdframe = 16;}
            else if (Cdraw == 17){Cdname = "  Azerbaijan   ", Cdarea = 86600, Cdframe = 17;}
            else if (Cdraw == 18){Cdname = "     Brasil    ", Cdarea = 8514877, Cdframe = 18;}
            else if (Cdraw == 19){Cdname = "    Canada     ", Cdarea = 9984670, Cdframe = 19;}
            else if (Cdraw == 20){Cdname = "  Cape Verde   ", Cdarea = 4033, Cdframe = 20;}
            else if (Cdraw == 21){Cdname = "    Denmark    ", Cdarea = 43094, Cdframe = 21;}
            else if (Cdraw == 22){Cdname = "   Ethiopia    ", Cdarea = 1104300, Cdframe = 22;}
            else if (Cdraw == 23){Cdname = "    France     ", Cdarea = 551500, Cdframe = 23;}
            else if (Cdraw == 24){Cdname = "    Germany    ", Cdarea = 357121, Cdframe = 24;}
            else if (Cdraw == 25){Cdname = "    Greece     ", Cdarea = 131957, Cdframe = 25;}
            else if (Cdraw == 26){Cdname = "   Hong Kong   ", Cdarea = 1104, Cdframe = 26;}
            else if (Cdraw == 27){Cdname = "     Iran      ", Cdarea = 1628750, Cdframe = 27;}
            else if (Cdraw == 28){Cdname = "    Jamaica    ", Cdarea = 10991, Cdframe = 28;}
            else if (Cdraw == 29){Cdname = "    Kuwait     ", Cdarea = 17818, Cdframe = 29;}
            else if (Cdraw == 30){Cdname = "   Maldives    ", Cdarea = 300, Cdframe = 30;}
            else if (Cdraw == 31){Cdname = "    Mexico     ", Cdarea = 1964375, Cdframe = 31;}
            else if (Cdraw == 32){Cdname = "   Mongolia    ", Cdarea = 1564116, Cdframe = 32;}
            else if (Cdraw == 33){Cdname = "    Myanmar    ", Cdarea = 676578, Cdframe = 33;}
            else if (Cdraw == 34){Cdname = "    Norway     ", Cdarea = 323787, Cdframe = 34;}
            else if (Cdraw == 35){Cdname = "     Oman      ", Cdarea = 309500, Cdframe = 35;}
            else if (Cdraw == 36){Cdname = "     Peru      ", Cdarea = 1285216, Cdframe = 36;}
            else if (Cdraw == 37){Cdname = "  Puerto Rico  ", Cdarea = 8870, Cdframe = 37;}
            else if (Cdraw == 38){Cdname = "    Romania    ", Cdarea = 238391, Cdframe = 38;}
            else if (Cdraw == 39){Cdname = "     Samoa     ", Cdarea = 2842, Cdframe = 39;}
            else if (Cdraw == 40){Cdname = " Saudi Arabia  ", Cdarea = 2149690, Cdframe = 40;}
            else if (Cdraw == 41){Cdname = "  South Korea  ", Cdarea = 100033, Cdframe = 41;}
            else if (Cdraw == 42){Cdname = "   Sri Lanka   ", Cdarea = 65610, Cdframe = 42;}
            else if (Cdraw == 43){Cdname = "    Sweden     ", Cdarea = 450295, Cdframe = 43;}
            else if (Cdraw == 44){Cdname = "     Syria     ", Cdarea = 185180, Cdframe = 44;}
            else if (Cdraw == 45){Cdname = "   Thailand    ", Cdarea = 513120, Cdframe = 45;}
            else if (Cdraw == 46){Cdname = "the Czech Republic", Cdarea = 78865, Cdframe = 46;}
            else if (Cdraw == 47){Cdname = "  Philippines  ", Cdarea = 300000, Cdframe = 47;}
            else if (Cdraw == 48){Cdname = "    Turkey     ", Cdarea = 783562, Cdframe = 48;}
            else if (Cdraw == 49){Cdname = "    Ukraine    ", Cdarea = 603500, Cdframe = 49;}
            else if (Cdraw == 50){Cdname = "   Venezuela   ", Cdarea = 912050, Cdframe = 50;}
        });

//タイトル画面
        var title = new Scene();

        game.pushScene(title);

        var haikei = new Sprite(320,320);
        haikei.backgroundColor = "rgb(100, 210, 230)";
        title.addChild(haikei);

        var quiz = new Sprite(320, 140);
        quiz.image = game.assets['quiz.png'];
        quiz.y = -15;
        quiz.scale(0.8, 0.8);
        title.addChild(quiz);

        var sora = new Sprite(237, 307);
        sora.image = game.assets['sora.png'];
        sora.frame = 0;
        sora.x = 45;
        sora.y = 60;
        title.addChild(sora);
        sora.addEventListener('enterframe', function(){
            if (this.age % 200 == 0 || this.age % 202 == 0) this.frame = 1;
            if (this.age % 201 == 0) this.frame = 2;
            else this.frame = 0;
        });

        var hand = new Sprite(200, 150);
        hand.image = game.assets['card.png'];
        hand.frame = 0;
        hand.x = 120;
        hand.y = 117;
        hand.scale(0.3, 0.3);
        title.addChild(hand);
        hand.addEventListener('enterframe', function(){
            if (tpha == 0) this.scaleX = this.scaleX - 0.02;
            if (tpha == 0 && this.scaleX <= 0) this.frame = Cdframe, tpha = 1;
            if (tpha == 1) this.scaleX = this.scaleX + 0.02;
            if (tpha == 1 && this.scaleX >= 0.3) tpha = 2;
            if (tpha == 2) this.scaleX = this.scaleX - 0.02;
            if (tpha == 2 && this.scaleX <= 0) this.frame = 0, tpha = 3;
            if (tpha == 3) this.scaleX = this.scaleX + 0.02;
            if (tpha == 3 && this.scaleX >= 0.3) tpha = 0;
        });

        var runb = new Label("Push   Run   Button");
        runb.x = 95;
        runb.y = 260;
        runb.color = "black";
        runb.font = "16px tahoma";
        runb.addEventListener('enterframe',function(){
            this.tl.fadeOut(1).delay(10).fadeIn(1).delay(30);
            this.tl.looped = true;
        });
        title.addChild(runb);

        var prod = new Label("Produced by YMIYASOFT");
        prod.x = 2;
        prod.y = 306;
        prod.color = "black";
        prod.font = "12px tahoma";
        title.addChild(prod);

        haikei.addEventListener('enterframe', function(){
            if (game.input.a) game.popScene(title);
        });

//枚数(スコア)
        var score = new Label("");
        score.x = 5;
        score.y = 0;
        score.color = "black";
        score.font = "20px tahoma";
        score.addEventListener('enterframe',function(){
            this.text = "Score : " + maisu;
            if (phase == 91) this.font = "24px tahoma";
        });
        game.rootScene.addChild(score);

//国旗1
        var card1 = new Sprite(200, 150);
        card1.image = game.assets['card.png'];
        card1.frame = 0;
        card1.x = 140;
        card1.y = 60;
        card1.scale(0.5, 0.5);
        card1.opacity = 0;

        card1.addEventListener('enterframe', function(){
            if (phase == 0 && game.input.a){
                Cname1 = Cdname;
                Carea1 = Cdarea;
                Cframe1 = Cdframe;
                card1.frame = Cframe1;
                card1.opacity = 1;
                wait = game.frame;
                phase = 1;                                //phase1 draw→1
            }
            if (phase == 1){
                card1.x -= 13.5;
                card1.scale(1.1, 1.1);                    //1
                CNlab1.opacity = 0;
                CNlab2.opacity = 0;
            }
            if (phase == 1 && wait + 4 < game.frame){
                card1.x = 60;
                wait = game.frame;
                phase = 2;                                //phase2
            }
            if (phase == 2 && wait + 30 < game.frame){
                wait = game.frame;
                phase = 3;                                //phase3
            }
            if (phase == 3){
                card1.x -= 13.5;
                card1.scale(0.9091, 0.9091);              //1
            }
            if (phase == 3 && wait + 4 < game.frame){
                Cname2 = Cdname;
                Carea2 = Cdarea;
                Cframe2 = Cdframe;
                card2.frame = Cframe2;
                card2.opacity = 1;
                card2.scale(1.85, 1.85);                  //2
                wait = game.frame;
                phase = 4;                                //phase4 draw→2
            }
            if (phase == 10 && game.input.a){
                Exce.opacity = 0;
                Judge1.opacity = 0;
                Judge2.opacity = 0;
                Big.opacity = 0;
                Cursor.opacity = 0;
                wait = game.frame;
                phase = 11;                               //phase11
            }
            if (phase == 11) card1.x -= 20;
            if (phase == 11 && wait + 4 < game.frame) phase = 12;  //phase12
            if (phase ==12){
                Cname1 = Cname2;
                Carea1 = Carea2;
                Cframe1 = Cframe2;
                card1.frame = Cframe1;
                card1.x = 140;
                card1.y = 60;
                card1.scale(1.1, 1.1);                   //1
                card2.opacity = 0;
                card2.frame = Cframe2;
                card2.x = 380;
                card2.y = 60;
                wait = game.frame;
                phase = 1;                               //phase1 2→1すり替え
            }
        });
        game.rootScene.addChild(card1);

//国旗2
        var card2 = new Sprite(200, 150);
        card2.image = game.assets['card.png'];
        card2.frame = 0;
        card2.x = 380;
        card2.y = 60;
        card2.scale(0.5, 0.5);
        card2.opacity = 0;

        card2.addEventListener('enterframe', function(){
            if (phase == 4){
                if (Carea1 == Carea2){
                    Cname2 = Cdname;
                    Carea2 = Cdarea;
                    Cframe2 = Cdframe;
                    card2.frame = Cframe2;
                    card2.x -= 29;
                }
                else {
                    card2.x -= 29;
                }
            }
            if (phase == 4 && wait + 10 < game.frame){
                wait = game.frame;
                phase = 5;                              //phase5
            }
            if (phase == 5 && wait + 30 < game.frame){
                wait = game.frame;
                phase = 6;                              //phase6
            }
            if (phase == 6){
                card2.x += 13.5;
                card2.scale(0.902, 0.902);                  //2
            }
            if (phase == 6 && wait + 4 < game.frame){
                wait = game.frame;
                phase = 7;                              //phase7
            }
        });

        game.rootScene.addChild(card2);

//国名1
        var CNlab1 = new Label("");
        CNlab1.x = 90;
        CNlab1.y = 35;
        CNlab1.color = "black";
        CNlab1.text = "";
        CNlab1.opacity = 0;
        CNlab1.addEventListener('enterframe', function(){
            this.text = Cname1;
            if (phase == 2) this.font = "25px tahoma", this.x = 90, this.y = 35, this.opacity = 1;
            if (phase == 4) this.font = "20px tahoma", this.x = 20, this.y = 45;
            if (phase == 5) this.opacity = 0;
            if (phase == 7) this.opacity = 1;
        });
        game.rootScene.addChild(CNlab1);

//国名2
        var CNlab2 = new Label("");
        CNlab2.x = 90;
        CNlab2.y = 35;
        CNlab2.color = "black";
        CNlab2.text = "";
        CNlab2.opacity = 0;
        CNlab2.addEventListener('enterframe', function(){
            this.text = Cname2;
            if (phase == 5) this.font = "25px tahoma", this.x = 90, this.y = 35, this.opacity = 1;
            if (phase == 7) this.font = "20px tahoma", this.x = 185, this.y = 45;
        });
        game.rootScene.addChild(CNlab2);

//Which is Bigger ?
        Big = new Label("");
        Big.x = 35;
        Big.y = 255;
        Big.color = "black";
        Big.font = "30px tahoma";
        Big.text = "Which  is  Bigger ?";
        Big.opacity = 0;
        Big.addEventListener('enterframe', function(){
            if (phase == 7 || phase ==8) this.opacity = 1;
        });
        game.rootScene.addChild(Big);

//カーソル
        Cursor = new Sprite(36, 36);
        Cursor.x = 60;
        Cursor.y = 190;
        Cursor.image = game.assets['kigou.png'];
        Cursor.frame = 0;
        Cursor.opacity = 0;
        Cursor.addEventListener('enterframe', function(){
            if (phase == 7 || phase ==8) this.opacity = 1;
            if (phase == 7 && game.input.right) Cursor.x = 225, select = 1;
            if (phase == 7 && game.input.left) Cursor.x = 60, select = 0;
        });
        game.rootScene.addChild(Cursor);

//＞＜
        Judge1 = new Sprite(36, 36);
        Judge1.x = 140;
        Judge1.y = 115;
        Judge1.image = game.assets['kigou.png'];
        Judge1.frame = 1;
        Judge1.opacity = 0;
        Judge1.addEventListener('enterframe', function(){
            if (phase == 7 && game.input.a){
                this.opacity = 1;
                wait = game.frame;
                phase = 8;                                        //phase8
            }
            if (phase == 8) this.rotate(45);
            if (phase == 8 && wait + 30 < game.frame){
                this.opacity = 0;
                phase = 9;                                        //phase9
            }
        });
        game.rootScene.addChild(Judge1);

        Judge2 = new Sprite(36, 36);
        Judge2.x = 140;
        Judge2.y = 115;
        Judge2.image = game.assets['kigou.png'];
        Judge2.frame = 1;
        Judge2.opacity = 0;
        Judge2.addEventListener('enterframe', function(){
            if (phase == 9 && Carea1 < Carea2){
                this.opacity = 1;
                this.frame = 1;
                this.scaleX = 1;
                if (select == 1) hantei = 0;
                if (select == 0) hantei = 1;
            }
            else if (phase == 9 && Carea1 > Carea2){
                this.opacity = 1;
                this.frame = 1;
                this.scaleX = -1;
                if (select == 1) hantei = 1;
                if (select == 0) hantei = 0;
            }
            else if (phase == 9 && Carea1 == Carea2){
                this.opacity = 1;
                this.frame = 2;
                if (select == 1) hantei = 0;
                if (select == 0) hantei = 0;
            }
        });
        game.rootScene.addChild(Judge2);

//Excellent Failure
        Exce = new Label("");
        Exce.x = 70;
        Exce.y = 215;
        Exce.font = "36px tahoma";
        Exce.opacity = 0;
        Exce.addEventListener('enterframe', function(){
            if (phase ==9 && Judge2.opacity == 1 && hantei ==0){
                maisu ++;
                this.color = "blue";
                this.text = "Excellent!!!";
                this.opacity = 1;
                phase = 10;                             //phase10
            }
            if (phase ==9 && Judge2.opacity == 1 && hantei ==1){
                this.color = "red";
                this.text = "   Failure  ";
                this.opacity = 1;
                wait = game.frame;
                phase = 90;                             //phase90
            }
            if (phase == 90 && wait + 30 < game.frame) phase = 91, this.text = "Game Over ";
        });
        game.rootScene.addChild(Exce);

//次回へのヒント
        Hint1 = new Label("");
        Hint1.x = 25;
        Hint1.y = 170;
        Hint1.color = "black";
        Hint1.font = "20px tahoma";
        Hint1.text = "";
        Hint1.opacity = 0;
        Hint1.addEventListener('enterframe', function(){
            if (phase == 91){
            this.text = Carea1 + " km2";
            this.opacity = 1;
            }
        });
        game.rootScene.addChild(Hint1);

        Hint2 = new Label("");
        Hint2.x = 200;
        Hint2.y = 170;
        Hint2.color = "black";
        Hint2.font = "20px tahoma";
        Hint2.text = "";
        Hint2.opacity = 0;
        Hint2.addEventListener('enterframe', function(){
            if (phase == 91){
            this.text = Carea2 + " km2";
            this.opacity = 1;
            }
        });
        game.rootScene.addChild(Hint2);

//タイトルへ戻る
        game.addEventListener('enterframe', function(){
            if (phase == 91 && game.input.b){
                phase = 0;
                maisu = 0;
                Hint1.opacity = 0;
                Hint2.opacity = 0;
                Exce.opacity = 0;
                Judge1.opacity = 0;
                Judge2.opacity = 0;
                Big.opacity = 0;
                Cursor.opacity = 0;
                card1.x = 140;
                card1.y = 60;
                card2.x = 380;
                card2.y = 60;
                game.pushScene(title);
            }
        });


/*デバッグ用
        var secret1 = new Label("");
        secret1.x = 0;
        secret1.y = 20;
        secret1.color = "black";
        secret1.font = "18px fantasy";
        secret1.addEventListener('enterframe',function(){
            this.text = "P " + phase + " S " + select + " H " + hantei + " C1 " + Carea1 + " C2 " + Carea2 + " Cd " + Cdraw;
        });
        game.rootScene.addChild(secret1);

        var secret2 = new Label("");
        secret2.x = 0;
        secret2.y = 300;
        secret2.color = "black";
        secret2.font = "18px fantasy";
        secret2.addEventListener('enterframe',function(){
            this.text = "W " + wait;
        });
        game.rootScene.addChild(secret2);
*/

    }

    game.start();
	xhrPad.start();                   // libXHRPad.jsの開始
};

//乱数n+1
function rand(n) {
    return Math.floor(Math.random() * n + 1);
}

