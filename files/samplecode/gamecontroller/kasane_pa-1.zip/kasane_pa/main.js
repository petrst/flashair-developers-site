enchant();
Score =enchant.Class.create({
	initialize:function(){
		this.score=0;
		this.label = new Label("SCORE:<BR>"+this.score);
		game.rootScene.addChild(this.label);
		this.label.x = 220;
		this.label.y =5;
		this.label.color ="#00ff00";
	},
	add:function(n){
		this.score+=n;
		this.label.text = "SCORE:<BR>"+this.score;
	}
});
TimeAttack =enchant.Class.create({
	initialize:function(){
		//時間ラベル設定
		this.timeLimit=60;
		this.timeLabel = new Label("TIME:"+this.timeLimit+".00");
		game.rootScene.addChild(this.timeLabel);
		this.timeLabel.x = 10;
		this.timeLabel.color="#000";
		this.timeLabel.font="bold";
		this.timeLabel.y =10;
		this.timeStart=new Date;//初期時間を設定
		this.timeInit=false;
		this.timerID =window.setInterval(this.interval, 100 ,this);
		this.idx=99999;


		countDown = new Sprite(16,16);
		countDown.image = game.assets['icon.gif'];
		countDown.x=160;
		countDown.y=-120;
		countDown.scaleX=10;
		countDown.scaleY=10;
		countDown.opacity=0.5;
		countDown.frame=8;
        game.rootScene.addChild(countDown);

	},
	interval:function(obj){
			if(gameStart){
				if(!obj.timeInit){
					obj.timeStart=new Date;//初期時間を設定
					obj.timeInit=true;
				}
				var timeLeft =((new Date)-obj.timeStart)/1000;
				
				if((obj.timeLimit-timeLeft)<10){
					var f =Math.floor(obj.timeLimit-timeLeft)-1;
					if(f<0)countDown.frame=9;
					else{
						countDown.frame=f;
					}
					countDown.y=120;
				}
				obj.idx =(obj.timeLimit-timeLeft);
				if((obj.timeLimit-timeLeft)<=0){ //タイムアップ
					countDown.y=-100;
					obj.timeLabel.text="TIME:0.00";
					obj.gameend(score.score,score.score+"点を獲得!");
				}
				else obj.timeLabel.text="TIME:"+obj.get2string(obj.timeLimit-timeLeft);;
			}
	},
	get2string:function (x){ //小数点以下2桁までで表示をカット
		n = new String(x);
		if(n.indexOf(".")>0)
			n = n.split(".")[0]+"."+(n.split(".")[1]+"00").substring(0,2);
		else 
			n = n+".00";
		return n;
	},
	gameend:function(score,str){ //ゲーム終了
		window.clearInterval(this.timerID);
		
		var ResultLabel =new Label(str);
		ResultLabel.x=80;
		ResultLabel.y=220;
		ResultLabel.color="#ffffff";
		ResultLabel.font="bold";
		game.rootScene.addChild(ResultLabel);
		
		game.end(score,str);
	
	}

});


Player = enchant.Class.create(enchant.Sprite,{ //Spriteクラスを継承してPlayerクラスを作る
	initialize:function(){
		enchant.Sprite.call(this,16,16); //Spriteクラスのコンストラクタ呼び出し
		this.image = game.assets['andy.gif'];
		this.frame = 0;
		this.x=160;
		this.y=160;
		game.rootScene.addChild(this);
		this.addEventListener('enterframe',this.padOperation);
	},
	padOperation:function(){
		this.x += pad.vx*5;
		this.y += pad.vy*5;
		if(Math.abs(pad.vx)>Math.abs(pad.vy)){
			if(pad.vx>0)this.frame=3;
			else this.frame=1;
		}else{
			if(pad.vy<0)this.frame=2;
			else this.frame=0;
		}
		gameStart=true;
	}
});

rand = function(max){
	return Math.floor(Math.random()*max);
}

treeList = [];


ScoreFlash = enchant.Class.create(enchant.Label,{ //Labelクラスを継承してScoreFlashクラスを作る
	initialize:function(x,y,score){
		enchant.Label.call(this,score); //Labelクラスのコンストラクタ呼び出し
		this.color="#00aa00";
		game.rootScene.addChild(this);
		this.x = x;
		this.y = y;
		this.addEventListener('enterframe',this.move);
		this.cnt=0;
	},
	move:function(){
		this.cnt++;
		if(this.cnt>10){
			this.removeEventListener('enterframe',this.move);
			game.rootScene.removeChild(this);
		}
	}
});


Effect = enchant.Class.create(enchant.Sprite,{ //Spriteクラスを継承してEffectクラスを作る
	initialize:function(x,y){
		enchant.Sprite.call(this,16,16); //Spriteクラスのコンストラクタ呼び出し
		this.image = game.assets['kirakira.gif'];
		game.rootScene.addChild(this);
		this.x = x;
		this.y = y;
		this.addEventListener('enterframe',this.move);
		this.cnt=0;
	},
	move:function(){
		this.cnt++;
		if(this.cnt%2==0){
			this.frame++;
			this.opacity*=0.8;
		}
		if(this.cnt>10){
			this.removeEventListener('enterframe',this.move);
			game.rootScene.removeChild(this);
		}
	}
});

Block = enchant.Class.create(enchant.Sprite,{ //Spriteクラスを継承してPlayerクラスを作る
	initialize:function(){
		enchant.Sprite.call(this,16,16); //Spriteクラスのコンストラクタ呼び出し
		this.image = game.assets['andy.png'];
		game.rootScene.addChild(this);
        this.frame=rand(4);
	},
	fix:function(){
        vmap[Math.floor(this.y/16)][Math.floor((this.x-8)/16)]=this;		
    }
});

var vmap = []; //仮想マップ
var vmapW = 12;
var vmapH = 19;

judgment = function(_x,_y){
	var x = Math.floor((_x-8)/16);
	var y = Math.floor(_y/16);

	var set = [];
	if(vmap[y][x]==0)return;
	var color = vmap[y][x].frame;

	var vmap2 = [];

  	for(var i=0;i<vmapH;i++){
    	vmap2[i]=new Array();
        for(var j=0;j<vmapW;j++){
        	vmap2[i][j]=vmap[i][j];
        }
    }

	var point=0;
	sentinel = function(x,y){
		set.push(vmap[y][x]);
		vmap2[y][x]=0;
		point++;
		if(x>0){
			if(vmap2[y][x-1])
			if(vmap2[y][x-1].frame==color){
				sentinel(x-1,y);
			}
		}
		if(x<vmapW){
			if(vmap2[y][x+1])
			if(vmap2[y][x+1].frame==color){
				sentinel(x+1,y);
			}
		}
		if(y>0){
			if(vmap2[y-1][x])
			if(vmap2[y-1][x].frame==color){
				sentinel(x,y-1);
			}
		}
		if(y<vmapH-1){
			if(vmap2[y+1][x])
			if(vmap2[y+1][x].frame==color){
				sentinel(x,y+1);
			}
		}
	};

	sentinel(x,y,0);
	if(point>4){
		console.log("pts:"+point);
		if((game.frame - scoreFrame)<　(interval*2+5+20)){
			rensa++;
			console.log("連鎖:"+rensa);
		}else{
			rensa=1;
		}
		e = new ScoreFlash(_x,_y,point*point*rensa*rensa);
		scoreFrame = game.frame;
		score.add(point*point*rensa*rensa);
		for(i=0;i<set.length;i++){
			var e = new Effect(set[i].x,set[i].y);
			set[i].y=-1000;
		}
	  	for(var i=0;i<vmapH;i++){
        	for(var j=0;j<vmapW;j++){
        		vmap[i][j]=vmap2[i][j];
        	}
    	}
	}

};
//判定する
scan = function(){
	for(var i=vmapH-1;i>0;i--){
		var flag=true;
    	for(var j=0;j<vmapW;j++){
			if(vmap[i][j]!=0){
				judgment(j*16+8,i*16);
				flag=false;
			}
        }
		if(flag)return; //一列全部空欄だったらテスト終了
    }

}

//ブロックを落としたりする
cleanup = function(){
	for(var i=vmapH-1;i>0;i--){
    	for(var j=0;j<vmapW;j++){
			if(vmap[i][j]==0)
				if(vmap[i-1][j]){
					vmap[i-1][j].y+=16;
					vmap[i][j]=vmap[i-1][j];
					vmap[i-1][j]=0;
				}
        }
    }
}

window.onload = function(){
    game = new Game(320, 320);
    game.fps = 20;
    game.preload('icon.gif','tree.gif','andy.png','kirakira.gif','back.png');
    game.life = 4;
    game.stage = 1;
    game.score = 0;
    game.onload = function(){
		bg = new Sprite(320,320);
		bg.image=game.assets['back.png'];
		game.rootScene.addChild(bg);
		
		scoreFrame=0;

		gameStart=false;
		timeAttack = new TimeAttack();
		score = new Score();
        
        
        for(var i=0;i<vmapH;i++){
            vmap[i]=new Array();
            for(var j=0;j<vmapW;j++){
                vmap[i][j]=0;
            }
        }
		
		var pad = new Pad();
		game.rootScene.addChild(pad);
     	pad.x=220;
		pad.y=200;

        b1= new Block();
        b1.x=120-8+2;
        b2= new Block();
        b2.x=120-8+2;
        b2.y=b1.y+16;
        b3= new Block();
        b3.x=120-8+2;
        b3.y=b2.y+16;

		interval = 15;
        
		game.rootScene.addEventListener('enterframe',function(){
			var keys = xhrPad.read();         // コントローラ・キーの読み出し
			if(game.frame%2==0){

			if(keys.left == true){
				if( (vmap[Math.floor(b1.y/16)][Math.floor((b1.x-8)/16)-1]==0)&&
					(vmap[Math.floor(b2.y/16)][Math.floor((b2.x-8)/16)-1]==0)&&
					(vmap[Math.floor(b3.y/16)][Math.floor((b3.x-8)/16)-1]==0)
					){
					b1.x-=16;
					b2.x-=16;
					b3.x-=16;
				}
			}
			if(keys.right == true){
				if( (vmap[Math.floor(b1.y/16)][Math.floor((b1.x-8)/16)+1]==0)&&
					(vmap[Math.floor(b2.y/16)][Math.floor((b2.x-8)/16)+1]==0)&&
					(vmap[Math.floor(b3.y/16)][Math.floor((b3.x-8)/16)+1]==0)){
					b1.x+=16;
					b2.x+=16;
					b3.x+=16;
				}
			}
			if(keys.up == true){

				b1.y+=16;
				b2.y-=16;
				tmp = b1;b1=b2;b2=tmp;

				b2.y+=16;
				b3.y-=16;
				tmp = b2;b2=b3;b3=tmp;

			}
			if(keys.down == true){
				if(b3.y<16*17)
                if(vmap[Math.floor(b3.y/16)+1][Math.floor((b3.x-8)/16)]==0){
                    b1.y+=16;
                    b2.y+=16;
                    b3.y+=16;
                }
			}
			}
			if((game.frame%(5000)==0)&&(interval<10)){
				interval=8;
			}
			if((game.frame%(8000)==0)&&(interval<10)){
				interval=4;
			}
			if((interval < 5) &&game.frame%(2000)==0){
				interval=15;
			}
			if(game.frame%(interval*10+300)==0){
				if(interval>1)interval--;
			}
			if(game.frame%(interval*2+5)==0)
				scan();
			if(game.frame%interval==0){
				cleanup();
                var stop=false;
                if(vmap[Math.floor(b3.y/16)+1][Math.floor((b3.x-8)/16)]==0){
                    b1.y+=16;
                    b2.y+=16;
                    b3.y+=16;
                }else
                    stop=true;
                    
                if( (b1.y>=16*18)||(b2.y>=16*18)||(b3.y>=16*18))
                    stop=true;

				if(stop){
					if(b1.y==0){
						game.end(score.score,score.score+"点だポヨ!");
						return;
					}
					b1.fix();
					b2.fix();
					b3.fix();
/*					judgment(b1.x,b1.y);
					if(b1.frame!=b2.frame)
						judgment(b2.x,b2.y);
  */                  b1= new Block();
                    b1.x=120-8+2;
                    b2= new Block();
                    b2.x=120-8+2;
                    b2.y=b1.y+16;
                    b3= new Block();
                    b3.x=120-8+2;
                    b3.y=b2.y+16;
                }
			}
		});

    }
    game.start();
    xhrPad.start();                   // libXHRPad.jsの開始
}

