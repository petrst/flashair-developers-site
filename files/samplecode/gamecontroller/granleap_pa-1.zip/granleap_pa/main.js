enchant();
rand = function(n){ //乱数を発生する関数
	return Math.floor(Math.random()*n);
}
//BGクラスの定義
BG = Class.create(Group,{ //Groupクラスを継承する
	initialize:function(){
		enchant.Group.call(this);
		this.bg1 = new Sprite(320,320);
		this.bg1.image = game.assets['map10.png'];
		this.addChild(this.bg1);
		this.bg2 = new Sprite(320,320);
		this.bg2.image = game.assets['map11.png'];
		this.bg2.y=-319;
		this.addChild(this.bg2);
		this.mapCount=2;
		this.addEventListener('enterframe',this.tick);
		
	},
	tick:function(){
		delta = player.x -160;
		this.x += ((-delta) - this.x)/10;
		if(this.x<-40)this.x=-40;
		if(this.x>40)this.x=40;
		this.bg1.y+=7;
		this.bg2.y+=7;
		if(this.bg1.y>=319){
			this.bg1.image = this.bg2.image;
			this.bg1.y=0;
			this.bg2.image = game.assets['map1'+this.mapCount+'.png'];
			this.bg2.y=-319;
			this.mapCount++;
			if(this.mapCount>5)this.mapCount=0;
		}
	}
});

//Playerクラスの定義
Player = Class.create(Sprite,{ //Spriteクラスを継承する
	initialize:function(x,y){
		enchant.Sprite.call(this,24,24); //Spriteクラスのコンストラクタ呼び出し
		this.image =game.assets['common.png'];
		this.addEventListener('enterframe',this.tick);
		this.frame=2;
//		this.tx=160;
		this.x = x;
		this.y = y;
		this.shot = false;
		this.isMuteki=false;
		this.mutekiStart=0;
	},
	tick:function(){
                var keys = xhrPad.read();         // コントローラ・キーの読み出し
//		var d = (this.tx-this.x)/10;
//		this.x += d;
//		if(d>8)this.frame = 4;
//		else
		if(keys.right == true)this.frame = 3;
		else
		if(keys.left == true)this.frame = 1;
		else
//		if(d<-8)this.frame = 0;
//		else
		this.frame=2;
		if(this.shot)
		if(game.frame%4==0){
			var shot = new PlayerShot(this.x+4-effectLayer.x,this.y-8);
		}
		if(this.isMuteki){
			this.y=-this.y;
			if(game.frame - this.mutekiStart >10){
				this.y = Math.abs(this.y);
				this.isMuteki = false;
			}
		}
        xhrPad.start();                   // libXHRPad.jsの開始
	},
	damage:function(){
		if(!this.isMuteki){
			game.life--;
			if(game.life<0){
				game.end(game.score,game.score);
			}
			this.mutekiStart = game.frame;
			this.isMuteki = true;
			game.combo=1;
		}
	}
});


//PlayerShotクラスの定義
PlayerShot = Class.create(Sprite,{ //Spriteクラスを継承する
	initialize:function(x,y){
		enchant.Sprite.call(this,16,16); //Spriteクラスのコンストラクタ呼び出し
		this.image =game.assets['shots.png'];
		this.addEventListener('enterframe',this.tick);
		this.frame=3;
		this.x = x;
		this.y = y;
		effectLayer.addChild(this);
	},
	tick:function(){
		this.y-=8;
		if(this.y<=0){
		}
		for(i in EnemyArray){
			if(this.intersect(EnemyArray[i])){
				game.score += game.combo;
				EnemyArray[i].hp--;
				if(EnemyArray[i].hp==0){
					var exp = new Explosion(EnemyArray[i].x,EnemyArray[i].y);
					EnemyArray[i].die();
				}		
				this.die();
				return;
			}
		}
	},
	die:function(){
			this.removeEventListener('enterframe',this.tick);
			effectLayer.removeChild(this);
	}
});


Array.prototype.remove=function(obj){
	for(i = 0; i < this.length; i++){
 		if(this[i] === obj){
 			this.splice(i,1);
		}
	}
}


var LockArray =[];

//Lockクラスの定義
Lock = Class.create(Sprite,{ //Spriteクラスを継承する
	initialize:function(obj){
		if(LockArray.length<4){
			LockArray.push(this);
			enchant.Sprite.call(this,24,24); //Spriteクラスのコンストラクタ呼び出し
			this.image =game.assets['common.png'];
			this.addEventListener('enterframe',this.tick);
			this.frame=5;
			this.x = obj.x;
			this.y = obj.y;
			this.tgt = obj;
			effectLayer.addChild(this);
			if(sound)
				game.assets['lock.wav'].clone().play();
		}
	},
	tick:function(){
		this.x = this.tgt.x+this.tgt.width/2-12;
		this.y = this.tgt.y+this.tgt.height/2-12;
		
		if(game.frame%2>0)return;
		this.frame++;
		if(this.frame>=8){
			this.frame=8;
		}
	},
	blast:function(){
		this.tgt.die();
	},
	unlock:function(){
		LockArray.remove(this);
		this.removeEventListener('enterframe',this.tick);
		effectLayer.removeChild(this);
	}
});

var laserCount=0;

//Laserクラスの定義
Laser = Class.create(Entity,{
	initialize:function(obj){
		if(LockArray.length<4){
			if(sound)
				game.assets['homing.wav'].clone().play();
			enchant.Entity.call(this); //Spriteクラスのコンストラクタ呼び出し
			this.addEventListener('enterframe',this.tick);
			this.x = player.x;
			this.y = player.y;
			this.v = 5;
			this.width = 1;
			this.height = 1;
			this.scaleX = 1;
			this.scaleY = 1;
			laserCount = 1- laserCount;
			this.r = laserCount* Math.PI;
			this.tgt = obj;
			this.tail = [];
			this.age=0;
			effectLayer.addChild(this);
			this.turnDir=laserCount%2 == 0 ? -1:1;
		}
	},
	tick:function(){
		if(this.age>20){
			this.tgt.unlock();
			this.unlock();
		}
		this.age++;
		//目標点との内積を取る
		var vx= Math.cos(this.r)*this.v;
		var vy= Math.sin(this.r)*this.v;
		var dx = this.tgt.x-this.x;
		var dy = this.tgt.y-this.y;

		this.x = this.x+vx;		
		this.y = this.y+vy;	
		this.v+=1.5;

		//外積を求める
		var op = vx*dy-dx*vy;
		if(this.age<5){
			if(op<0)
				this.r-=0.3;
			else
				this.r+=0.3;
		}else{
			if(this.turnDir>0){
				if(op>0)this.r+=0.1;
			}
			else {
				if(op<0)
				this.r-=0.1;
			}
		}
		this.tail.push({x:this.x,y:this.y});
		laserCtx.strokeStyle = "rgba(0, 255, 0,128)";
		laserCtx.beginPath();
		laserCtx.lineWidth=2;
		laserCtx.moveTo(this.tail[0].x,this.tail[0].y);
		for(i=0;i<this.tail.length;i++){
			laserCtx.lineTo(this.tail[i].x,this.tail[i].y);
		}
        laserCtx.stroke();
		if(this.tgt.within(this,this.v*2)){
			var exp = new Explosion(this.tgt.x,this.tgt.y);
			this.tgt.blast();
			this.tgt.unlock();
			game.combo++;
		}
		if(this.tail.length>10)this.tail.shift();
	},
	unlock:function(){
		this.removeEventListener('enterframe',this.tick);
		effectLayer.removeChild(this);
	}
});



//Explosionクラスの定義
Explosion = Class.create(Sprite,{ //Spriteクラスを継承する
	initialize:function(x,y){
		enchant.Sprite.call(this,24,24); //Spriteクラスのコンストラクタ呼び出し
		this.image =game.assets['common.png'];
		this.addEventListener('enterframe',this.tick);
		this.frame=10;
		this.x = x;
		this.y = y;
		this.scaleX=2;
		this.scaleY=2;
		effectLayer.addChild(this);
		if(sound)
			game.assets['bomb.wav'].play();
	},
	tick:function(){
		this.frame++;
		if(this.frame>=18){
			this.removeEventListener('enterframe',this.tick);
			effectLayer.removeChild(this);
		}
	}
});


EnemyArray =[];



//Enemyクラスの定義
Enemy = Class.create(Sprite,{ //Spriteクラスを継承する
	initialize:function(x,y,type,p){
		switch(type){
			case 2:
				enchant.Sprite.call(this,64,26); //Spriteクラスのコンストラクタ呼び出し
				this.image =game.assets['enemy01b.png'];
				this.hp = 10;
				break;
			default:
				enchant.Sprite.call(this,16,16); //Spriteクラスのコンストラクタ呼び出し
				this.image =game.assets['enemy01.png'];
				this.hp = 2;
				this.frame=3;
		}
		this.addEventListener('enterframe',this.tick);
		this.x = x;
		this.y = y;
		this.age=0;
		this.pattern = p;
		this.isLock=false;
		enemyLayer.addChild(this);
		EnemyArray.push(this);
	},
	tick:function(){
	
		this.x += EnemyMove[this.pattern][this.age*3];
		this.y += EnemyMove[this.pattern][this.age*3+1];
		if(EnemyMove[this.pattern][this.age*3+2]>0){
			var es = new EnemyShot(this.x+this.width/2-8,this.y+16);
		}
		if(!this.isLock){
			if(Math.abs(this.x-player.x)<5){
				if(LockArray.length<4){
					this.lock  = new Lock(this);
					this.isLock=true;
				}
			}
		}
/*		if(game.frame%2==0)
		if(EnemyMove[this.pattern][this.age*3]!=0){
			this.rotation = -90+Math.atan(EnemyMove[this.pattern][this.age*3+1]/
										EnemyMove[this.pattern][this.age*3])
													/Math.PI*180;
		}
*/		this.age++;
		if( ((this.x<-30)&&(this.y<320)&&(this.y>-30))||
			((this.x>330)&&(this.y<320)&&(this.y>-30))||
			((this.age>10)&&(this.y<-30))||
			 (this.y>=320) || EnemyMove[this.pattern].length<this.age){
			this.die();
		}
	},
	die:function(){
		if(this.isLock){
			this.lock.unlock();
			this.isLock=false;
		}
		this.removeEventListener('enterframe',this.tick);
		enemyLayer.removeChild(this);
		EnemyArray.remove(this);
	}
});

//Bossクラスの定義
Boss = Class.create(Sprite,{ //Spriteクラスを継承する
	initialize:function(x,y){
		enchant.Sprite.call(this,210,92); //Spriteクラスのコンストラクタ呼び出し
		this.image =game.assets['boss.png'];
		this.hp = 100;
		this.frame=3;
		this.addEventListener('enterframe',this.tick);
		this.x = x;
		this.y = y;
		this.age=0;
		this.mode=0;
		this.isLock=false;
		enemyLayer.addChild(this);
		this.hit = new Sprite(30,20);
		this.hit.hp=1;
		this.hit.isLock=false;
		boss = this;
		this.hit.die = function(){
			boss.frame=0;
			if(boss.y>0)
				boss.y-=5;
			this.hp=1;
			this.isLock=false;
			boss.hp--;
			if(boss.hp<=0){
				boss.removeEventListener('enterframe',boss.tick);
				boss.addEventListener('enterframe',boss.dead);
				this.removeEventListener('enterframe',this.tick);
				enemyLayer.removeChild(this);
				EnemyArray.remove(this);
				boss.deadStep=0;
			}
		}
		EnemyArray.push(this.hit);
	},
	dead:function(){
		if(this.deadStep<30){
			for(i=0;i<5;i++){
				var exp = new Explosion(this.x+
									Math.random()*210*this.scaleX+this.deadStep,
										this.y+
									Math.random()*60*this.scaleY+this.deadStep/2);
			}
			this.deadStep++;
		}
		this.y++;
		this.scaleX*=0.98;
		this.scaleY*=0.98;
		player.y-=this.deadStep;
		if(player.y<-50){
            this.endScene = new SplashScene();
			game.endScene.image = game.assets['clear.png']; 
			game.end(game.score,game.score);
		}
	},
	tick:function(){
		this.hit.x=this.x+90;
		this.hit.y=this.y+40;

		if(!this.hit.isLock){
			if(Math.abs(this.hit.x+20-player.x)<2){
				if(LockArray.length<4){
					this.hit.lock  = new Lock(this.hit);
					this.hit.isLock=true;
				}
			}
		}



		if(this.age<60){
			this.y+=(60-this.age)/20;
		}else{
			if(this.y<10){
				this.y+=this.y/10+1;
				if(game.frame%4==0)this.frame=1;
			}
			switch(this.mode){
				case 0:
					this.x--;
					if(this.x<-20)
						this.mode=1;
					break;
				case 1:
					this.x++;
					if(this.x>100)
						this.mode=0;
					break;
				case 2:
					this.frame=1-this.frame;
					if(game.frame>this.start+20){
						this.mode=3;
						this.start=game.frame;
					}
					break;
				case 3:
					this.frame=0;
					bl = new BossLaser(this.x+100,60,this);		
					if(game.frame>this.start+50)
						this.mode=Math.random()>0.5 ? 0:1;

			}
			if(this.age%150==0){
					this.mode=2;
					if(sound)
						game.assets['st_laser.wav'].clone().play();
					this.start = game.frame;
			}
			if(this.mode<2){
				if(this.age%15==0){
					var es = new EnemyShot(this.x+105,this.y+80,2);
					var es = new EnemyShot(this.x+105-40,this.y+80,2);
					var es = new EnemyShot(this.x+105-80,this.y+80,2);
					var es = new EnemyShot(this.x+105+40,this.y+80,2);
					var es = new EnemyShot(this.x+105+80,this.y+80,2);
				}
			}
		}
		this.age++;
	}
});

//BossLaserクラスの定義
BossLaser = Class.create(Entity,{ //Entityクラスを継承する
	initialize:function(x,y,boss){
		enchant.Entity.call(this); //Entityクラスのコンストラクタ呼び出し
		this.owner=boss;
		this.x=x;
		this.y=y;
		this.mode=0;
		this.start=game.frame;
		this.addEventListener('enterframe',this.tick);
		effectLayer.addChild(this);
	},
	tick:function(){
		bosslaserLayer.x=effectLayer.x;
		ctx =bossCtx;
		if(game.frame%2>0)return;
		switch(this.mode){
			case 0:
				ctx.fillStyle = "rgb(255,255,255)";
				ctx.fillRect(0,0,320,320);
				this.mode++;
				break;
			case 1:
				ctx.fillStyle = "rgb(0, 0, 0)";
				ctx.fillRect(0,0,320,320);
				this.mode++;
				break;
			case 2:
				this.owner.frame=1;
				ctx.fillStyle = "rgb(255, 0, 0)";
				ctx.fillStyle = "rgba(128,60, 0,128)";
				ctx.fillRect(this.x-1,this.y,9,320);
				ctx.fillStyle = "rgb(255,120, 0)";
				ctx.fillRect(this.x,this.y,7,320);
				ctx.fillStyle = "rgb(255, 255, 255)";
				ctx.fillRect(this.x+2,this.y,3,320);
				this.mode++;
				break;
			case 3:
				ctx.clearRect(0,0,320,320);
				ctx.fillStyle = "rgba(128,60, 0,128)";
				ctx.fillRect(this.x-1,this.y,9,320);
				ctx.fillStyle = "rgb(255,120, 0)";
				ctx.fillRect(this.x,this.y,7,320);
				ctx.fillStyle = "rgb(255, 255, 255)";
				ctx.fillRect(this.x+2,this.y,3,320);
				this.mode++;
				break;
		}
		if(game.frame > this.start+40){
				ctx.clearRect(0,0,320,320);
				this.die();
		}
		if(Math.abs(player.x-this.x)<5){
			player.damage();
		}
	},
	die:function(){
			this.removeEventListener('enterframe',this.tick);
			effectLayer.removeChild(this);
	}

});
	

//EnemyShotクラスの定義
EnemyShot = Class.create(Sprite,{ //Spriteクラスを継承する
	initialize:function(x,y,type){
		enchant.Sprite.call(this,16,16); //Spriteクラスのコンストラクタ呼び出し
		this.image =game.assets['shots.png'];
		this.addEventListener('enterframe',this.tick);
		this.frame=1;
		this.x = x;
		this.y = y;
		this.vx = (player.x-effectLayer.x) -x;
		this.vy = (player.y-effectLayer.y) -y;
		len = this.vx*this.vx+this.vy*this.vy;
		if(len!=0){
			len = Math.sqrt(len);
			this.vx /= len;
			this.vy /= len;
			this.vx*=3;
			this.vy*=3;
		}
		if(type==2){
			this.vx*=2;
			this.vy*=2;
//			this.frame=0;
		}
		effectLayer.addChild(this);
	},
	tick:function(){
		this.x += this.vx;
		this.y += this.vy;
		if( ((this.x<-30)&&(this.y<320)&&(this.y>-30))||
			((this.x>330)&&(this.y<320)&&(this.y>-30))||
			( this.age>100)){
			this.die();
		}
		if((Math.abs(player.y-this.y)<5)&&
		   (Math.abs(player.x-effectLayer.x-this.x)<5)){
			player.damage();
			this.die();
		}
	},
	die:function(){
			this.removeEventListener('enterframe',this.tick);
			effectLayer.removeChild(this);
	}
});

//初期化
window.onload = function(){
	game = new Game(320, 320);
	game.fps=20;
	game.life=3;
	game.combo=1;
	game.score=0;

	if(/chrome/i.test(navigator.userAgent)){
//	if(/webkit/i.test(navigator.userAgent)){
		game.preload('common.png','clear.png',
			'lock.wav','homing.wav','st_laser.wav',
			'STAR1.mp3','bomb.wav','BOSS.mp3',
			'shots.png','enemy01.png','enemy01b.png','boss.png',
			'map10.png','map11.png','map12.png','map13.png','map14.png','map15.png');
		sound=true;
	}else{//音楽非対応
		game.preload('common.png','clear.png',
			'shots.png','enemy01.png','enemy01b.png','boss.png',
			'map10.png','map11.png','map12.png','map13.png','map14.png','map15.png');
		sound=false;
	}
	game.onload = function(){
		//BGを表示
		bg = new BG();
		game.rootScene.addChild(bg);

		//プレイヤーを表示
		player = new Player(160,280);
		game.rootScene.addChild(player);

		game.rootScene.addEventListener('enterframe',function(){
			var keys = xhrPad.read();         // コントローラ・キーの読み出し
			if (keys.b == true) player.shot=true;
			if (keys.b == false) player.shot=false;
                        if (keys.left == true) player.x -= 8;
                        if (keys.right == true) player.x += 8;
			if (keys.a) for(i=0;i<LockArray.length;i++){
				var laser = new Laser(LockArray[i]);
			}
		});
		
		waveCount=0;
		bossMode=false;
		isStart=true;
		game.rootScene.addEventListener('enterframe',function(e){
			if(isStart){
				isStart=false;
				game.frame=0;
				if(sound)
					game.assets['STAR1.mp3'].play();
			}
			if(!bossMode){
//				if(game.frame>10){
				if(enemyWave.length <= waveCount){
					bossMode=true;
					if(sound){
						game.assets['STAR1.mp3'].stop();
						game.assets['BOSS.mp3'].play();
					}
					//ボス
					boss = new Boss(60,-100);
		
				}else
				if(enemyWave[waveCount][0]<game.frame){
				var enemy = new Enemy(enemyWave[waveCount][1],enemyWave[waveCount][2]/2,
										enemyWave[waveCount][3],enemyWave[waveCount][4]);
					waveCount++;
				}
			}
			if(game.frame%2==0){
				laserCtx.clearRect(0,0,320,320);
			}
		});
		//ボスレーザーエリア
		bosslaserLayer = new Sprite(320,320);
		bossSurface = new Surface(320,320);
		bosslaserLayer.image = bossSurface;
		bossCtx = bossSurface.context;
		game.rootScene.addChild(bosslaserLayer);


		//エネミー表示レイヤー
		enemyLayer = new Group();
		game.rootScene.addChild(enemyLayer);
		enemyLayer.addEventListener('enterframe',function(){
			if(player.x<90){
				player.x=90;
				this.x+=2;
			}else
			if(player.x>320-90-24){
				player.x=320-90-24;
				this.x-=2;
			}
			if(this.x<-40)this.x=-40;
			if(this.x>40)this.x=40;
			effectLayer.x = this.x;
			laserSurface.x = this.x;
		});

		//エフェクト表示レイヤー
		effectLayer = new Group();
		game.rootScene.addChild(effectLayer);
		

		//レーザー表示エリア
		laserLayer = new Sprite(320,320);
		laserSurface = new Surface(320,320);
		laserLayer.image = laserSurface;
		laserCtx = laserSurface.context;
		game.rootScene.addChild(laserLayer);
		
		//マスクエリア
		maskLayer = new Sprite(320,320);
		maskSurface = new Surface(320,320);
		maskLayer.image = maskSurface;
		ctx = maskSurface.context;
		game.rootScene.addChild(maskLayer);
		
		ctx.fillStyle = "rgb(0, 0, 0)";
		ctx.fillRect(0,0,40,320);
		ctx.fillRect(320-40,0,320,320);

		//ライフゲージ
		lifeGuage = new Label("");
		lifeGuage.x=45;
		lifeGuage.y=10;
		lifeGuage.font="6px sans- serif";
		lifeGuage.color="#ffff00";
		lifeGuage.addEventListener('enterframe',function(){
			if(game.frame%16>0)return;
			this.text = "LIFE:";
			for(i=0;i<game.life;i++)
				this.text += "★";
		});
		game.rootScene.addChild(lifeGuage);

		//スコアゲージ
		scoreGuage = new Label("");
		scoreGuage.x=200;
		scoreGuage.y=10;
		scoreGuage.color="#ffff00";
		scoreGuage.font="6px sans- serif";
		scoreGuage.addEventListener('enterframe',function(){
			if(game.frame%16>0)return;
			this.text = "SCORE:"+game.score*10;
		});
		game.rootScene.addChild(scoreGuage);

    }
    game.start();
    xhrPad.start();                   // libXHRPad.jsの開始
}

